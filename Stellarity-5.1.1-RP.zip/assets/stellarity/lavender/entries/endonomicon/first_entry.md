```json
{
  "title": "My First Page",
  "icon": "minecraft:quartz",
  "category": "stellarity:weapons",
  "associated_items": [
    "minecraft:nether_quartz_ore"
  ]
}
```

In here, we put some **markdown-formatted** content for our entry. Lavender 
supports most of the *standard* Markdown formatting syntax with some 
{green}minecraft-specific{} extensions, like this one for color

;;;;;

This above page-break syntax (;;;;;) starts the next page.
<recipe;minecraft:furnace>

;;;;;

<item;minecraft:diamond_shovel[item_model="stellarity:shulker_shovel"]>