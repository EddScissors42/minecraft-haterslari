```json
{
  "title": "Mobs",
  "icon": "minecraft:ender_dragon_spawn_egg"
}
```
There aren't really any new mobs, more like variants of the existing ones.
