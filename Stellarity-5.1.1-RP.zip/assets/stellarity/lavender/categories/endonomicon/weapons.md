```json
{
  "title": "Weapons",
  "icon": "minecraft:stick[item_model=\"stellarity:tamaris\"]"
}
```
