```json
{
  "title": "Light and Dark",
  "icon": "minecraft:stick[item_model=\"stellarity:altar_of_the_accursed\"]"
}
```

The End is a realm where Light and Dark magic meet and mix together.
