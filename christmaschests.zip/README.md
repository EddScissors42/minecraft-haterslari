# ChristmasChestsAllYear

**SUPPORT FOR NEW PALE OAK CHEST BOAT!!!**

Changes the default texture of chests to their Christmas textures and adds new ones.
Ideal for making content or Christmas themed builds!
New textures for:

- Enderchests
- Boats with chests
- Llamachests
- Donkey-/Mulechests
- Trappedchests and Trappeddoublechests
