--Cyber was here :3

--this will be used to make the left hand. i can multiple values from the right hand with l so it mirrors it correctly on the left hand
local l = bl and 1 or -1

if (
    I:isOf(item, Items:get("minecraft:bucket")) or
    I:isOf(item, Items:get("minecraft:water_bucket")) or
    I:isOf(item, Items:get("minecraft:lava_bucket")) or
    I:isOf(item, Items:get("minecraft:powder_snow_bucket")) or
    I:isOf(item, Items:get("minecraft:pufferfish_bucket")) or
    I:isOf(item, Items:get("minecraft:cod_bucket")) or
    I:isOf(item, Items:get("minecraft:tropical_fish_bucket")) or
    I:isOf(item, Items:get("minecraft:salmon_bucket")) or
    I:isOf(item, Items:get("minecraft:tadpole_bucket")) or
    I:isOf(item, Items:get("minecraft:axolotl_bucket")) 
) then
    M:moveX(matrices, 0 * l)
    M:moveY(matrices, 0.12)
    M:moveZ(matrices, -0.05)

    M:rotateX(matrices, 65)
    M:rotateY(matrices, 180)
    M:rotateZ(matrices, -15 * l)
end
if (
    I:isOf(item, Items:get("minecraft:milk_bucket"))
    ) then
    M:moveX(matrices, 0 * l)
    M:moveY(matrices, 0.1)
    M:moveZ(matrices, 0.03)

    M:rotateX(matrices, 100)
    M:rotateY(matrices, -170)
    M:rotateZ(matrices, -195 * l)
end
if (
     I:isOf(item, Items:get("minecraft:suspicious_stew")) or
    I:isOf(item, Items:get("minecraft:rabbit_stew")) or
    I:isOf(item, Items:get("minecraft:mushroom_stew")) or
    I:isOf(item, Items:get("minecraft:beetroot_soup")) or
     I:isOf(item, Items:get("minecraft:bowl"))
    ) then
    M:moveX(matrices, 0 * l)
    M:moveY(matrices, 0.15)
    M:moveZ(matrices, 0.03)

    M:rotateX(matrices, 100)
    M:rotateY(matrices, -170)
    M:rotateZ(matrices, -195 * l)

    M:scale(matrices, 1.5, 1.3, 1.5)
end

if P:isUsingItem(player) and I:isOf(item, Items:get("minecraft:milk_bucket")) then
--positions here
end

local soups = {
    "minecraft:suspicious_stew",
    "minecraft:rabbit_stew",
    "minecraft:mushroom_stew",
    "minecraft:beetroot_soup"
}

for _, id in ipairs(soups) do
if P:isUsingItem(player) and  I:isOf(item, Items:get(id)) then
--positions here
end