--stop snooping in my shit!
local l = (bl and 1) or -1
local d = (bl and 1) or -0.5
local sh = false
local a = false
local s = false
local pic = false
local hoe = false
local m = false

global.fall = 0.0;
global.pitchAngle = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle = 0.0;
global.yawAngleO = 0.0;

local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

local swords = {
    "minecraft:wooden_sword",
    "minecraft:stone_sword",
    "minecraft:iron_sword",
    "minecraft:golden_sword",
    "minecraft:copper_sword",
    "minecraft:diamond_sword",
    "minecraft:netherite_sword",
    "minecraft:trident"
}

local pickaxes = {
    "minecraft:wooden_pickaxe",
    "minecraft:stone_pickaxe",
    "minecraft:iron_pickaxe",
    "minecraft:golden_pickaxe",
    "minecraft:copper_pickaxe",
    "minecraft:diamond_pickaxe",
    "minecraft:netherite_pickaxe",
    "minecraft:mace",
}

local axes = {
    "minecraft:wooden_axe",
    "minecraft:stone_axe",
    "minecraft:iron_axe",
    "minecraft:golden_axe",
    "minecraft:copper_axe",
    "minecraft:diamond_axe",
    "minecraft:netherite_axe"
}

local shovels = {
    "minecraft:wooden_shovel",
    "minecraft:stone_shovel",
    "minecraft:iron_shovel",
    "minecraft:golden_shovel",
    "minecraft:copper_shovel",
    "minecraft:diamond_shovel",
    "minecraft:netherite_shovel"
}

local hoes = {
    "minecraft:wooden_hoe",
    "minecraft:stone_hoe",
    "minecraft:iron_hoe",
    "minecraft:golden_hoe",
    "minecraft:copper_hoe",
    "minecraft:diamond_hoe",
    "minecraft:netherite_hoe"
}

local miscItems = {
    "minecraft:shield",
    "minecraft:flint_and_steel",
    "minecraft:fishing_rod",
    "minecraft:carrot_on_a_stick",
    "minecraft:warped_fungus_on_a_stick",
    "minecraft:stick",
    "minecraft:brush",
    "minecraft:enchanted_golden_apple",
    "minecraft:shears",
    "minecraft:bow",
    "minecraft:crossbow",
    "minecraft:enchanted_book",
    "minecraft:nether_star",
    "minecraft:crossbow",
    
    "enderscape:mirror",
    "enderscape:magnia_attractor",
    "enderscape:end_stone_rubble_shield",
    "enderscape:veradite_rubble_shield",
    "enderscape:mirestone_rubble_shield",
    "enderscape:kurodite_rubble_shield",

    "farmersdelight:flint_knife",
    "farmersdelight:iron_knife",
    "farmersdelight:stone_knife",
    "farmersdelight:diamond_knife",
    "farmersdelight:golden_knife",
    "farmersdelight:netherite_knife"
}

--swords

for _, id in ipairs(swords) do
        if I:isOf(item, Items:get(id)) and I:isEnchanted(item, Items:get(id)) then
            s = true
            break
        end
    end
    if s then
    particleManager:addParticle(particles,
        false,
        0 * l,
        0.5,
        0,
        0,
        0,
        0,
        10*l,
        0,
        0,
        0,
        0,
        0,
        3, Texture:of("minecraft", "textures/particle/p_glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 115)
    end

    --axes

for _, id in ipairs(axes) do
        if I:isOf(item, Items:get(id)) and I:isEnchanted(item, Items:get(id))  then
            a = true
            break
        end
    end
    if a then
    particleManager:addParticle(particles,
        false,
        0 * l,
        0,
        0,
        0,
        0,
        0,
        10*l,
        0,
        0,
        0,
        0,
        0,
        3, Texture:of("minecraft", "textures/particle/p_glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 115)
    end

--shovels
--i said stop snooping
for _, id in ipairs(shovels) do
        if I:isOf(item, Items:get(id)) and I:isEnchanted(item, Items:get(id))  then
            sh = true
            break
        end
    end
    if sh then
    particleManager:addParticle(particles,
        false,
        -0.2 * l,
        0.4,
        0,
        0,
        0,
        0,
        10*l,
        0,
        0,
        0,
        0,
        0,
        3, Texture:of("minecraft", "textures/particle/p_glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 115)
    end

    --pickaxes

    for _, id in ipairs(pickaxes) do
        if I:isOf(item, Items:get(id)) and I:isEnchanted(item, Items:get(id))  then
            pic = true
            break
        end
    end
    if pic then
    particleManager:addParticle(particles,
        false,
        0.2 * l, --x
        0, --y
        0, --x
        0,
        0,
        0,
        10*l,
        0,
        0,
        0,
        0,
        0,
        3, Texture:of("minecraft", "textures/particle/o_glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 115)
    end

    --hoes

    for _, id in ipairs(hoes) do
        if I:isOf(item, Items:get(id)) and I:isEnchanted(item, Items:get(id))  then
            hoe = true
            break
        end
    end
    if hoe then
    particleManager:addParticle(particles,
        false,
        0.2 * d,
        0.3,
        0,
        0,
        0,
        0,
        10*l,
        0,
        0,
        0,
        0,
        0,
        3, Texture:of("minecraft", "textures/particle/h_glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 115)
    end


    --misc items


        for _, id in ipairs(miscItems) do
        if I:isOf(item, Items:get(id)) and I:isEnchanted(item, Items:get(id))  then
            m = true
            break
        end
    end
    if m then
    particleManager:addParticle(particles,
        false,
        0 * d,
        0,
        0,
        0,
        0,
        0,
        10*l,
        0,
        0,
        0,
        0,
        0,
        3, Texture:of("minecraft", "textures/particle/misc_glow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 115)
    end